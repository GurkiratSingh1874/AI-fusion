"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

export default function TrackEWaste() {
  const [items, setItems] = useState([])
  const [newItem, setNewItem] = useState({ name: "", description: "", weight: "" })

  const handleSubmit = (e) => {
    e.preventDefault()
    setItems([...items, { ...newItem, id: Date.now() }])
    setNewItem({ name: "", description: "", weight: "" })
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Track E-Waste</h1>
      <form onSubmit={handleSubmit} className="mb-8 space-y-4">
        <div>
          <Label htmlFor="name">Item Name</Label>
          <Input
            id="name"
            value={newItem.name}
            onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
            required
          />
        </div>
        <div>
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            value={newItem.description}
            onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
          />
        </div>
        <div>
          <Label htmlFor="weight">Weight (kg)</Label>
          <Input
            id="weight"
            type="number"
            value={newItem.weight}
            onChange={(e) => setNewItem({ ...newItem, weight: e.target.value })}
            required
          />
        </div>
        <Button type="submit">Add Item</Button>
      </form>
      <h2 className="text-2xl font-bold mb-4">Tracked Items</h2>
      <ul className="space-y-2">
        {items.map((item) => (
          <li key={item.id} className="border p-4 rounded">
            <h3 className="font-bold">{item.name}</h3>
            <p>{item.description}</p>
            <p>Weight: {item.weight} kg</p>
          </li>
        ))}
      </ul>
    </div>
  )
}

