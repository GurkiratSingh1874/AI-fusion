import { Button } from "@/components/ui/button"
import Link from "next/link"
import { motion } from "framer-motion"

export default function Home() {
  return (
    <div className="text-center">
      <motion.h1
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-5xl font-bold mb-6 text-green-600"
      >
        Welcome to AI-Powered E-Waste Tracker
      </motion.h1>
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.5 }}
        className="mb-8 text-xl"
      >
        Efficiently manage and track your electronic waste disposal with the power of AI
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6, duration: 0.5 }}
        className="space-x-4"
      >
        <Button asChild size="lg">
          <Link href="/scan">Scan E-Waste</Link>
        </Button>
        <Button asChild variant="outline" size="lg">
          <Link href="/track">Track E-Waste</Link>
        </Button>
        <Button asChild variant="secondary" size="lg">
          <Link href="/dispose">Manage Disposal</Link>
        </Button>
      </motion.div>
    </div>
  )
}

