import { NextResponse } from "next/server"
import Replicate from "replicate"

const replicate = new Replicate({
  auth: process.env.REPLICATE_API_TOKEN,
})

export async function POST(req: Request) {
  if (!process.env.REPLICATE_API_TOKEN) {
    console.error("REPLICATE_API_TOKEN is not set")
    return NextResponse.json({ error: "Server configuration error" }, { status: 500 })
  }

  let image
  try {
    const body = await req.json()
    image = body.image
  } catch (error) {
    console.error("Error parsing request body:", error)
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 })
  }

  if (!image) {
    return NextResponse.json({ error: "No image provided" }, { status: 400 })
  }

  try {
    const output = await replicate.run(
      "salesforce/blip:2e1dddc8621f72155f24cf2e0adbde548458d3cab9f00c0139eea840d0ac4746",
      {
        input: {
          image: image,
          task: "image_captioning",
        },
      },
    )

    console.log("Replicate API response:", output)

    if (!output || typeof output !== "string") {
      console.error("Unexpected output from Replicate API:", output)
      return NextResponse.json({ error: "Unexpected API response" }, { status: 500 })
    }

    // This is a simplified response. In a real-world scenario, you'd want to map the AI output
    // to specific e-waste types and provide more detailed information.
    const result = {
      type: output,
      description:
        "This is a placeholder description. In a real application, you would provide detailed information about the identified e-waste type.",
      disposalMethod: "Please consult your local e-waste recycling guidelines for proper disposal methods.",
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error processing image:", error)
    return NextResponse.json({ error: "Failed to process image", details: error.message }, { status: 500 })
  }
}

