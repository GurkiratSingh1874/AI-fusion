import { motion } from "framer-motion"

export default function Footer() {
  return (
    <motion.footer
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.5 }}
      className="bg-green-600 text-white text-center py-4"
    >
      <p>&copy; 2023 AI-Powered E-Waste Tracker. All rights reserved.</p>
    </motion.footer>
  )
}

