import Link from "next/link"
import { motion } from "framer-motion"

export default function Header() {
  return (
    <motion.header initial={{ y: -100 }} animate={{ y: 0 }} className="bg-green-600 text-white shadow-md">
      <nav className="container mx-auto px-4 py-4">
        <ul className="flex space-x-4 justify-center">
          <li>
            <Link href="/" className="hover:underline text-lg font-semibold">
              Home
            </Link>
          </li>
          <li>
            <Link href="/scan" className="hover:underline text-lg font-semibold">
              Scan E-Waste
            </Link>
          </li>
          <li>
            <Link href="/track" className="hover:underline text-lg font-semibold">
              Track E-Waste
            </Link>
          </li>
          <li>
            <Link href="/dispose" className="hover:underline text-lg font-semibold">
              Disposal Management
            </Link>
          </li>
        </ul>
      </nav>
    </motion.header>
  )
}

