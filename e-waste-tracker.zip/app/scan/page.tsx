"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { motion } from "framer-motion"
import Image from "next/image"
import { useToast } from "@/components/ui/use-toast"

export default function ScanEWaste() {
  const [image, setImage] = useState(null)
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const handleImageUpload = (e) => {
    const file = e.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => setImage(e.target.result)
      reader.readAsDataURL(file)
    }
  }

  const scanImage = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image }),
      })
      const data = await response.json()
      if (response.ok) {
        setResult(data)
      } else {
        throw new Error(data.error || "An error occurred while scanning the image")
      }
    } catch (error) {
      console.error("Error scanning image:", error)
      toast({
        title: "Error",
        description: error.message || "An error occurred while scanning the image",
        variant: "destructive",
      })
      setResult(null)
    }
    setLoading(false)
  }

  return (
    <div className="max-w-2xl mx-auto">
      <motion.h1
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-3xl font-bold mb-6 text-center text-green-600"
      >
        AI-Powered E-Waste Scanner
      </motion.h1>
      <Card>
        <CardHeader>
          <CardTitle>Upload an image of e-waste</CardTitle>
          <CardDescription>Our AI will identify the type of e-waste and provide information about it.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="image">Upload Image</Label>
            <Input id="image" type="file" accept="image/*" onChange={handleImageUpload} />
          </div>
          {image && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative w-full h-64"
            >
              <Image src={image || "/placeholder.svg"} alt="Uploaded e-waste" layout="fill" objectFit="contain" />
            </motion.div>
          )}
          <Button onClick={scanImage} disabled={!image || loading} className="w-full">
            {loading ? "Scanning..." : "Scan Image"}
          </Button>
          {result && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mt-4">
              <h2 className="text-xl font-semibold mb-2">Scan Results:</h2>
              <p>
                <strong>Type:</strong> {result.type}
              </p>
              <p>
                <strong>Description:</strong> {result.description}
              </p>
              <p>
                <strong>Disposal Method:</strong> {result.disposalMethod}
              </p>
            </motion.div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

