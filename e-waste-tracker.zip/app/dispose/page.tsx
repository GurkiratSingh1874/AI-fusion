"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function DisposalManagement() {
  const [disposals, setDisposals] = useState([])
  const [newDisposal, setNewDisposal] = useState({ date: "", method: "", quantity: "" })

  const handleSubmit = (e) => {
    e.preventDefault()
    setDisposals([...disposals, { ...newDisposal, id: Date.now() }])
    setNewDisposal({ date: "", method: "", quantity: "" })
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Disposal Management</h1>
      <form onSubmit={handleSubmit} className="mb-8 space-y-4">
        <div>
          <Label htmlFor="date">Disposal Date</Label>
          <Input
            id="date"
            type="date"
            value={newDisposal.date}
            onChange={(e) => setNewDisposal({ ...newDisposal, date: e.target.value })}
            required
          />
        </div>
        <div>
          <Label htmlFor="method">Disposal Method</Label>
          <Select
            value={newDisposal.method}
            onValueChange={(value) => setNewDisposal({ ...newDisposal, method: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select a method" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="recycling">Recycling</SelectItem>
              <SelectItem value="refurbishment">Refurbishment</SelectItem>
              <SelectItem value="landfill">Landfill</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="quantity">Quantity (kg)</Label>
          <Input
            id="quantity"
            type="number"
            value={newDisposal.quantity}
            onChange={(e) => setNewDisposal({ ...newDisposal, quantity: e.target.value })}
            required
          />
        </div>
        <Button type="submit">Add Disposal</Button>
      </form>
      <h2 className="text-2xl font-bold mb-4">Disposal Records</h2>
      <ul className="space-y-2">
        {disposals.map((disposal) => (
          <li key={disposal.id} className="border p-4 rounded">
            <p>Date: {disposal.date}</p>
            <p>Method: {disposal.method}</p>
            <p>Quantity: {disposal.quantity} kg</p>
          </li>
        ))}
      </ul>
    </div>
  )
}

